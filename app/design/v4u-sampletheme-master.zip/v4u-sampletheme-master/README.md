# V4U-Sampletheme
Magento2 Sampletheme.

Run the following commands:

php bin/magento setup:upgrade

php bin/magento setup:static-content:deploy

php bin/magento cache:clean

Now You can set New Theme from Admin Panel

Content->Design->Configuration->Edit->Default Theme->Applied Theme->Select Your New Theme->Save Configuraton.

<b>Supports : Magento 2.0.x, 2.1.x, 2.2.x, 2.3.x and 2.4.x</b>
