<?php
namespace Dev\Grid\Ui\DataProvider\Category;


class ListingDataProvider extends \Magento\Framework\View\Element\UiComponent\DataProvider\DataProvider
{
}
