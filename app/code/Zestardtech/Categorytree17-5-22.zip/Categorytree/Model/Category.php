<?php
namespace Zestardtech\Categorytree\Model;
// use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
use Magento\Framework\Model\AbstractModel;
class Category extends  AbstractModel
{

/*  protected function _construct()
   {
      /* Main Table Name */
     // $this->_init('catalog_category_entity','entity_id');
  // }*/


    // const TBL_FEATURED_PRODUCTS = 'zestard_featured_products';
    /**
     //* @var \Magento\Framework\Stdlib\DateTime
     */
    // protected $_dateTime;

    protected $_dateTime;
    /**
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\Zestardtech\Categorytree\Model\ResourceModel\Category\Collection::class);
    }
}