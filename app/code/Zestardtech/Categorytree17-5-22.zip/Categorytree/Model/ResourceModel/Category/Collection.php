<?php
namespace Zestardtech\Categorytree\Model\ResourceModel\Category;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
  protected function _construct()
  {
    $this->_init('Zestardtech\Categorytree\Model\Category', 
    'Zestardtech\Categorytree\Model\ResourceModel\Category');
   }
protected function _initSelect()
{
    parent::_initSelect();
     return $this;
   }
}