<?php
namespace Zestardtech\Categorytree\Model\ResourceModel;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
class Category extends  AbstractDb
{

  protected function _construct()
   {
      /* Main Table Name */
     $this->_init('catalog_category_entity','entity_id');
   }
}