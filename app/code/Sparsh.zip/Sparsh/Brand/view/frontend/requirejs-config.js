var config = {
    paths: {
        slick: 'Sparsh_Brand/js/slick'
    },
    shim: {
        slick: {
            deps: ['jquery']
        }
    }
};
